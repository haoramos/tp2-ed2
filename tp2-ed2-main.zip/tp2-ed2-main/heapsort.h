#ifndef HEAPSORT_H
#define HEAPSORT_H

#include "structs.h"

void heapSortMarcados(Aluno[], int n);

#endif