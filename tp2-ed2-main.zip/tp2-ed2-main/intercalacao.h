#ifndef INTERCALCAO_H
#define INTERCALCAO_H

#include "structs.h"

void intercalacao2f(FILE**);
void ImprimirArquivo(FILE*);

#endif